const fs = require("fs").promises;
const { prompt } = require("inquirer");

async function generateCode(prompt) {
  if (prompt.toLowerCase().includes("auth screen")) {
    const template = `
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import { supabase } from './supabase';

export default function AuthScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) Alert.alert('Login Error', error.message);
    else {
      Alert.alert('Success', 'Logged in successfully!');
      navigation.replace('Welcome');
    }
  };

  const handleSignup = async () => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) Alert.alert('Signup Error', error.message);
    else Alert.alert('Signup Success', 'You can now log in!');
  };

  return (
    <View>
      <Text>Auth Screen</Text>
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} />
      <TextInput placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry={true} />
      <Button title="Login" onPress={handleLogin} />
      <Button title="Sign Up" onPress={handleSignup} />
    </View>
  );
}

AuthScreen.propTypes = {
  navigation: PropTypes.shape({
    replace: PropTypes.func.isRequired,
  }).isRequired,
};
    `;
    return template;
  } else if (prompt.toLowerCase().includes("welcome screen")) {
    const template = `
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { View, Text, TextInput, Button, Alert, FlatList, StyleSheet } from 'react-native';
import { supabase } from './supabase';

export default function WelcomeScreen({ navigation }) {
  const [note, setNote] = useState('');
  const [notes, setNotes] = useState([]);

  const fetchNotes = async () => {
    const user = await supabase.auth.getUser();
    const { data, error } = await supabase.from('notes').select('*').eq('user_id', user.data.user.id).order('created_at', { ascending: false });
    if (error) Alert.alert('Error', error.message);
    else setNotes(data || []);
  };

  useEffect(() => { fetchNotes(); }, []);

  const handleAddNote = async () => {
    if (note.trim()) {
      const user = await supabase.auth.getUser();
      const { error } = await supabase.from('notes').insert({ content: note, user_id: user.data.user.id });
      if (error) Alert.alert('Error', error.message);
      else { setNote(''); fetchNotes(); }
    }
  };

  const handleDeleteNote = async (noteId) => {
    const { error } = await supabase.from('notes').delete().eq('id', noteId);
    if (error) Alert.alert('Error', error.message);
    else fetchNotes();
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    Alert.alert('Logged Out', 'You have been logged out.');
    navigation.replace('Auth');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to NoteApp!</Text>
      <TextInput style={styles.input} placeholder="Add a note" value={note} onChangeText={setNote} />
      <Button title="Add Note" onPress={handleAddNote} />
      <FlatList
        data={notes}
        renderItem={({ item }) => (
          <View style={styles.noteContainer}>
            <Text style={styles.note}>{item.content}</Text>
            <Button title="Delete" onPress={() => handleDeleteNote(item.id)} color="red" />
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
        style={styles.list}
      />
      <Button title="Logout" onPress={handleLogout} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 5 },
  list: { marginTop: 20 },
  noteContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 },
  note: { padding: 10, borderBottomWidth: 1, borderBottomColor: '#eee', flex: 1 },
});

WelcomeScreen.propTypes = {
  navigation: PropTypes.shape({
    replace: PropTypes.func.isRequired,
  }).isRequired,
};
    `;
    return template;
  }
  return "// No template for this prompt yet";
}

async function main() {
  let userPrompt = process.env.PROMPT_INPUT; // Check for env variable first
  if (!userPrompt) {
    const answers = await prompt([
      {
        type: "input",
        name: "prompt",
        message: "What feature do you want to implement?",
      },
    ]);
    userPrompt = answers.prompt;
  }

  let filePath = "output/AuthScreen.js";
  if (userPrompt.toLowerCase().includes("welcome screen")) {
    filePath = "output/WelcomeScreen.js";
  }
  const code = await generateCode(userPrompt);
  await fs.mkdir("output", { recursive: true });
  await fs.writeFile(filePath, code);
  console.log(`Generated code saved to ${filePath}`);
}

main();