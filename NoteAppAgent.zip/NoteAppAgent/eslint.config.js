const reactPlugin = require("eslint-plugin-react");
const globals = require("globals");

module.exports = [
  {
    languageOptions: {
      ecmaVersion: 2021,
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
      },
      parserOptions: {
        ecmaFeatures: { jsx: true },
      },
    },
    plugins: {
      react: reactPlugin,
    },
    rules: {
      // Manually include rules from eslint:recommended
      "no-unused-vars": "error",
      "no-undef": "error",
      // Add more rules from eslint:recommended as needed
      // Manually include rules from plugin:react/recommended
      ...reactPlugin.configs.recommended.rules,
      "react/react-in-jsx-scope": "off", // React 17+ doesn't need React import for JSX
    },
    settings: {
      react: { version: "detect" },
    },
  },
];