
import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet, Platform } from 'react-native';
import { supabase } from './supabase';
import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function ReminderScreen({ route, navigation }) {
  const { noteId } = route.params;
  const [reminderDate, setReminderDate] = useState('');

  const requestPermissions = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Denied', 'Notification permissions are required to set reminders.');
      return false;
    }
    return true;
  };

  const scheduleNotification = async () => {
    const date = new Date(reminderDate);
    if (isNaN(date.getTime())) {
      Alert.alert('Invalid Date', 'Please enter a valid date (YYYY-MM-DD HH:MM).');
      return;
    }

    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Note Reminder',
        body: 'You have a note reminder!',
      },
      trigger: { date },
    });

    const { error } = await supabase
      .from('notes')
      .update({ reminder: reminderDate })
      .eq('id', noteId);
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Reminder set successfully!');
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      <Text>Set Reminder for Note</Text>
      <TextInput
        style={styles.input}
        placeholder="YYYY-MM-DD HH:MM (e.g., 2025-06-05 14:30)"
        value={reminderDate}
        onChangeText={setReminderDate}
      />
      <Button title="Set Reminder" onPress={scheduleNotification} />
      <Button title="Cancel" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 5 },
});
    