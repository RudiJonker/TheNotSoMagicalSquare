
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import { supabase } from './supabase';

export default function EditNoteScreen({ route, navigation }) {
  const { noteId, initialContent } = route.params;
  const [content, setContent] = useState(initialContent);

  useEffect(() => {
    setContent(initialContent);
  }, [initialContent]);

  const handleSave = async () => {
    const { error } = await supabase
      .from('notes')
      .update({ content })
      .eq('id', noteId);
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Note updated!');
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      <Text>Edit Note</Text>
      <TextInput
        style={styles.input}
        value={content}
        onChangeText={setContent}
        multiline
      />
      <Button title="Save" onPress={handleSave} />
      <Button title="Cancel" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 5, minHeight: 100 },
});
    