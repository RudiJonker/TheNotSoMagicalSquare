const fs = require("fs").promises;
const { ESLint } = require("eslint");

async function testCode(filePath) {
  try {
    // Read the generated code file
    const code = await fs.readFile(filePath, "utf8");

    // Initialize ESLint with the configuration file
    const eslint = new ESLint({
      overrideConfigFile: "eslint.config.js",
      fix: false,
    });

    // Lint the code
    const results = await eslint.lintText(code, { filePath });
    const errorCount = results[0].errorCount;
    const warningCount = results[0].warningCount;

    if (errorCount > 0 || warningCount > 0) {
      console.error(`Test failed: Found ${errorCount} errors and ${warningCount} warnings.`);
      results[0].messages.forEach((msg) => {
        console.error(`- ${msg.ruleId} (${msg.severity === 2 ? "Error" : "Warning"}): ${msg.message} at line ${msg.line}, column ${msg.column}`);
      });
      console.log("Code test failed. Sending back for correction.");
      return false;
    }

    console.log("Test passed: No syntax errors or warnings found.");
    console.log("Code test successful. Ready to integrate.");
    return true;
  } catch (error) {
    console.error(`Test failed: ${error.message}`);
    console.log("Code test failed. Sending back for correction.");
    return false;
  }
}

async function main() {
  const filePath = "output/AuthScreen.js"; // Explicitly target the generated file
  if (await fs.stat(filePath).catch(() => null)) {
    const testResult = await testCode(filePath);
    if (!testResult) {
      console.log("Code sent back to Agent 1 for correction.");
    }
  } else {
    console.log("No code file to test.");
  }
}

main();