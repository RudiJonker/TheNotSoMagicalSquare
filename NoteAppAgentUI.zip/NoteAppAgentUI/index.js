const express = require('express');
const app = express();
const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.render('index', { prompt: '', code: '// Enter a prompt to generate code', testResult: '' });
});

app.post('/generate', async (req, res) => {
  const prompt = req.body.prompt || '';
  let code = '// No code generated yet';
  let testResult = '';

  if (prompt) {
    try {
      // Run agent.js to generate code
      await execPromise('node agent.js', {
        cwd: '../NoteAppAgent',
        env: { ...process.env, PROMPT_INPUT: prompt },
      });

      // Read the generated code
      const filePath = prompt.toLowerCase().includes("welcome screen")
        ? '../NoteAppAgent/output/WelcomeScreen.js'
        : '../NoteAppAgent/output/AuthScreen.js';
      code = await fs.readFile(filePath, 'utf8');

      // Run tester.js to test the code
      const { stdout } = await execPromise('node tester.js', { cwd: '../NoteAppAgent' });
      testResult = stdout;
    } catch (error) {
      code = `// Error: ${error.message}`;
      testResult = `Test error: ${error.message}`;
    }
  }

  res.render('index', { prompt, code, testResult });
});

app.listen(3000, () => console.log('UI running on http://localhost:3000'));